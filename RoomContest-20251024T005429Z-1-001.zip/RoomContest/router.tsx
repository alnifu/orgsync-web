import {
  createBrowserRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";
import PrivateRoute from "./components/PrivateRoute";
import Dashboard from "./pages/Dashboard";

import Signup from "./pages/Signup";
import Signin from "./pages/Signin";
import NewsFeed from "./pages/dashboard/NewsFeed";
import Events from "./pages/dashboard/Events";
import Organizations from "./pages/dashboard/Organizations";
import Profile from "./pages/dashboard/Profile";
import Games from "./pages/dashboard/Games";
import DashboardHome from "./pages/dashboard/DashboardHome";
import QuizGames from "./pages/dashboard/QuizGame";
import RoomGame from "./pages/dashboard/RoomGame";
import QuizSelection from "./pages/dashboard/QuizSelection";
import LeaderboardPage from "./pages/dashboard/LeaderboardPage";
import CommunityGoalsPage from "./pages/dashboard/CommunityGoalsPage"; // ✅ member view
import CommunityGoalsManagerPage from "./pages/dashboard/CommunityGoalsManager"; // ✅ officer view
import CreateQuiz from "./pages/dashboard/CreateQuiz"; // ✅ Add this import
import OfficerContestManager from "./pages/dashboard/OfficerContestManager"; // ✅ new
import OfficerSubmissions from "./pages/dashboard/OfficerSubmissions";
import MemberContests from "./pages/dashboard/MemberContests";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/signin" replace />,
  },
  { path: "/signin", element: <Signin /> },
  { path: "/signup", element: <Signup /> },
  {
    path: "/dashboard",
    element: (
      <PrivateRoute>
        <Dashboard />
      </PrivateRoute>
    ),
    children: [
      { index: true, element: <DashboardHome /> },
      { path: "newsfeed", element: <NewsFeed /> },
      { path: "events", element: <Events /> },
      { path: "organizations", element: <Organizations /> },
      { path: "profile", element: <Profile /> },
      { path: "games", element: <Games /> },
      { path: "leaderboard", element: <LeaderboardPage /> },
      { path: "community-goals", element: <CommunityGoalsPage /> },
      { path: "community-goals-manager", element: <CommunityGoalsManagerPage /> },
      { path: "contest-dashboard", element: <OfficerContestManager /> }, // ✅ replaced
      { path: "officer-submissions", element: <OfficerSubmissions /> },
      { path: "member-contests", element: <MemberContests /> },

    ],
  },
  { path: "/quiz-selec", element: <QuizSelection /> },
  { path: "/quiz-games", element: <QuizGames /> },
  { path: "/room-game", element: <RoomGame /> },
  { path: "/quiz-create", element: <CreateQuiz /> },
]);
export default function Root() {
  return <RouterProvider router={router} />;
}
