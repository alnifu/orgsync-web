import React, { useEffect, useState } from "react";
import { Unity, useUnityContext } from "react-unity-webgl";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { supabase } from "../../lib/supabase";

const RoomGame: React.FC = () => {
  const { unityProvider, isLoaded, loadingProgression, sendMessage } = useUnityContext({
    loaderUrl: "/unity/game1/Build/This.loader.js",
    dataUrl: "/unity/game1/Build/This.data",
    frameworkUrl: "/unity/game1/Build/This.framework.js",
    codeUrl: "/unity/game1/Build/This.wasm",
  });

  const navigate = useNavigate();
  const { user } = useAuth();

  const [unityReady, setUnityReady] = useState(false);
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [contests, setContests] = useState<any[]>([]);
  const [selectedContest, setSelectedContest] = useState<string>("");
  const [resolvedOrgId, setResolvedOrgId] = useState<string | null>(null);
  const [orgOptions, setOrgOptions] = useState<any[]>([]);
  const [loadingContests, setLoadingContests] = useState(false);

  // 🔹 Unity → React callbacks
  useEffect(() => {
    (window as any).NotifyReactUserReady = (userId: string) => {
      console.log("✅ Unity signaled ready for user:", userId);
      setUnityReady(true);
    };

    (window as any).SendScreenshotToReact = (base64: string) => {
      console.log("📸 Screenshot received from Unity!");
      setScreenshot(base64); // Opens preview popup
    };

    return () => {
      delete (window as any).NotifyReactUserReady;
      delete (window as any).SendScreenshotToReact;
    };
  }, []);

  // 🔹 Send user ID to Unity
  useEffect(() => {
    if (!user || !isLoaded) return;
    console.log("➡️ Sending user ID to Unity:", user.id);
    sendMessage("Gmanager", "InitializeFromJS", user.id);
  }, [user, isLoaded, sendMessage]);

  // 🔹 Resolve org memberships
  useEffect(() => {
    const resolveOrg = async () => {
      if (!user) return;

      let orgs: any[] = [];
      const { data: memberships, error } = await supabase
        .from("org_members")
        .select("org_id, organizations(name)")
        .eq("user_id", user.id)
        .eq("is_active", true);

      if (error) {
        console.error("❌ Error fetching org_members:", error);
        return;
      }

      if (memberships && memberships.length > 0) {
        orgs = memberships.map((m) => ({
          id: m.org_id,
          name: m.organizations?.name || "Unnamed Org",
        }));

        setOrgOptions(orgs);
        console.log("✅ Found org memberships:", orgs);
      } else {
        console.warn("⚠️ No org memberships found for user.");
      }
    };

    resolveOrg();
  }, [user]);

  // 🔹 Load active contests from Supabase
  useEffect(() => {
    const fetchContests = async () => {
      if (!resolvedOrgId) return;
      setLoadingContests(true);
      const { data, error } = await supabase
        .from("room_contests")
        .select("id, title")
        .eq("org_id", resolvedOrgId)
        .eq("is_active", true);

      setLoadingContests(false);

      if (error) console.error("❌ Error fetching contests:", error);
      else {
        console.log(`✅ Loaded ${data?.length || 0} contests for org ${resolvedOrgId}`);
        setContests(data || []);
      }
    };
    fetchContests();
  }, [resolvedOrgId]);

  // 🔹 Ask Unity to capture a screenshot
  const handleScreenshot = () => {
    if (!isLoaded) return alert("Game not loaded yet!");
    console.log("📸 Asking Unity to take screenshot...");
    sendMessage("Managers", "CaptureScreenshot");
  };

  // 🔹 Upload Screenshot to Supabase
  const handleSubmitScreenshot = async () => {
    if (!screenshot || !selectedContest || !user || !resolvedOrgId)
      return alert("Missing screenshot, contest, user, or org ID.");

    try {
      // Convert Base64 to Blob
      const blob = await (await fetch(screenshot)).blob();
      const fileName = `screenshots/${Date.now()}-${user.id}.png`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from("screenshots")
        .upload(fileName, blob);
      if (uploadError) throw uploadError;

      // Get Public URL
      const { data: publicData } = supabase.storage
        .from("screenshots")
        .getPublicUrl(fileName);
      const imageUrl = publicData.publicUrl;

      // Insert record into contest_submissions table
      const { error: insertError } = await supabase.from("contest_submissions").insert({
        user_id: user.id,
        org_id: resolvedOrgId,
        contest_id: selectedContest,
        image_url: imageUrl,
        submitted_at: new Date().toISOString(),
      });

      if (insertError) throw insertError;

      alert("✅ Screenshot submitted successfully!");
      setScreenshot(null);
      setSelectedContest("");
    } catch (err: any) {
      console.error("❌ Upload failed:", err);
      alert("Failed to submit screenshot.");
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        background: "#000",
      }}
    >
      {/* 🔸 Top Bar */}
      <div
        style={{
          padding: "10px",
          background: "rgba(0,0,0,0.7)",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        {/* ← Back Button */}
        <button
          onClick={() => navigate(-1)}
          style={{
            padding: "8px 16px",
            background: "#16a34a",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          ← Back
        </button>

        {/* 📸 Take Screenshot */}
        <button
          onClick={handleScreenshot}
          style={{
            padding: "8px 16px",
            background: "#2563eb",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          📸 Take Screenshot
        </button>

        {/* 🏢 Org Picker (only if multiple orgs) */}
        {orgOptions.length > 1 && (
          <select
            value={resolvedOrgId || ""}
            onChange={(e) => setResolvedOrgId(e.target.value)}
            style={{
              padding: "8px",
              borderRadius: "6px",
              background: "#111",
              color: "#fff",
              border: "1px solid #333",
            }}
          >
            <option value="">Select Organization</option>
            {orgOptions.map((org) => (
              <option key={org.id} value={org.id}>
                {org.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* 🔸 Unity Game */}
      <div
        style={{
          flex: 1,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          overflow: "hidden",
        }}
      >
        {!isLoaded && (
          <p style={{ color: "#fff", marginBottom: "1rem" }}>
            Loading... {Math.round(loadingProgression * 100)}%
          </p>
        )}
        <Unity
          unityProvider={unityProvider}
          style={{
            width: "100%",
            height: "100%",
            maxWidth: "960px",
            maxHeight: "600px",
            background: "#000",
          }}
        />
      </div>

      {/* 🔸 Screenshot Popup */}
      {screenshot && (
        <div
          style={{
            position: "absolute",
            bottom: 20,
            left: "50%",
            transform: "translateX(-50%)",
            background: "rgba(0,0,0,0.85)",
            padding: "20px",
            borderRadius: "12px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            color: "#fff",
          }}
        >
          <img
            src={screenshot}
            alt="Screenshot preview"
            style={{
              width: "300px",
              borderRadius: "8px",
              marginBottom: "10px",
            }}
          />

         {/* Contest Dropdown */}
<select
  value={selectedContest}
  onChange={(e) => setSelectedContest(e.target.value)}
  size={Math.min(contests.length, 5)} // show max 5 options, scroll if more
  style={{
    padding: "6px",
    borderRadius: "6px",
    marginBottom: "10px",
    width: "250px",
    color: "#000000",          // text color
    backgroundColor: "#ffffff", // dropdown background
    border: "1px solid #ccc",
    overflowY: "auto",          // scroll for extra options
    fontSize: "14px",
  }}
>
  {contests.length === 0 && (
    <option value="">
      {loadingContests ? "Loading contests..." : "No active contests"}
    </option>
  )}
  {contests.map((c) => (
    <option key={c.id} value={c.id}>
      {c.title}
    </option>
  ))}
</select>

          <div style={{ display: "flex", gap: "10px" }}>
            <button
              onClick={handleSubmitScreenshot}
              style={{
                background: "#16a34a",
                color: "#fff",
                border: "none",
                padding: "8px 16px",
                borderRadius: "8px",
                cursor: "pointer",
              }}
            >
              Submit to Contest
            </button>
            <button
              onClick={() => setScreenshot(null)}
              style={{
                background: "#dc2626",
                color: "#fff",
                border: "none",
                padding: "8px 16px",
                borderRadius: "8px",
                cursor: "pointer",
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoomGame;
