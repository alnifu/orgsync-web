import React, { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";

interface Organization {
  id: string;
  name: string;
}

interface Quiz {
  id: number;
  title: string;
}

interface CommunityGoal {
  id: string;
  org_id: string;
  quiz_id: number;
  goal_type: "score" | "participants";
  goal_target: number;
  reward_coins: number;
  is_completed: boolean;
  current_progress: number;
  created_at: string;
}

const CommunityGoalsManager: React.FC = () => {
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [selectedOrg, setSelectedOrg] = useState<string>("");
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [goals, setGoals] = useState<CommunityGoal[]>([]);
  const [loading, setLoading] = useState(true);

  const [goalType, setGoalType] = useState<"score" | "participants">("score");
  const [goalTarget, setGoalTarget] = useState<number>(0);
  const [rewardCoins, setRewardCoins] = useState<number>(0);
  const [selectedQuiz, setSelectedQuiz] = useState<number | null>(null);

  // 1️⃣ Fetch officer's organizations via org_managers
  useEffect(() => {
    const fetchOfficerOrgs = async () => {
      setLoading(true);
      try {
        const { data: userData } = await supabase.auth.getUser();
        const user = userData?.user;
        if (!user) return;

        // Fetch orgs linked to this user in org_managers
        const { data: orgManagerData, error: orgManagerError } = await supabase
          .from("org_managers")
          .select("org_id")
          .eq("user_id", user.id);

        if (orgManagerError) throw orgManagerError;

        const orgIds = orgManagerData?.map((o) => o.org_id) || [];
        if (orgIds.length === 0) {
          setOrgs([]);
          return;
        }

        // Fetch organization details
        const { data: orgData, error: orgError } = await supabase
          .from("organizations")
          .select("id, name")
          .in("id", orgIds);

        if (orgError) throw orgError;

        setOrgs(orgData || []);
        if (orgData && orgData.length > 0) setSelectedOrg(orgData[0].id);
      } catch (err) {
        console.error("❌ Error fetching orgs:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchOfficerOrgs();
  }, []);

  // 2️⃣ Fetch quizzes for selected org
  useEffect(() => {
    if (!selectedOrg) return;

    const fetchQuizzes = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("quizzes")
          .select("id, title, org_id")
          .eq("org_id", selectedOrg);

        if (error) throw error;
        setQuizzes(data || []);
      } catch (err) {
        console.error("❌ Error fetching quizzes:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchQuizzes();
  }, [selectedOrg]);

  // 3️⃣ Fetch existing community goals for org
  const fetchGoals = async () => {
    if (!selectedOrg) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("community_goals")
        .select("*")
        .eq("org_id", selectedOrg)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (err) {
      console.error("❌ Error fetching goals:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoals();
  }, [selectedOrg]);

  // 4️⃣ Create a new goal
  const handleCreateGoal = async () => {
    if (!selectedOrg || !selectedQuiz || goalTarget <= 0 || rewardCoins <= 0) {
      alert("⚠️ Please fill in all fields properly.");
      return;
    }

    try {
      const { error } = await supabase.from("community_goals").insert([
        {
          org_id: selectedOrg,
          quiz_id: selectedQuiz,
          goal_type: goalType,
          goal_target: goalTarget,
          reward_coins: rewardCoins,
          current_progress: 0,
          is_completed: false,
        },
      ]);

      if (error) throw error;

      alert("✅ Goal created successfully!");
      setGoalTarget(0);
      setRewardCoins(0);
      fetchGoals();
    } catch (err) {
      console.error("❌ Error creating goal:", err);
      alert("Failed to create goal.");
    }
  };

  // 5️⃣ Delete a goal
  const handleDeleteGoal = async (goalId: string) => {
    if (!window.confirm("Are you sure you want to delete this goal?")) return;

    try {
      const { error } = await supabase
        .from("community_goals")
        .delete()
        .eq("id", goalId);

      if (error) throw error;
      setGoals((prev) => prev.filter((g) => g.id !== goalId));
    } catch (err) {
      console.error("❌ Error deleting goal:", err);
      alert("Failed to delete goal.");
    }
  };

  if (loading) return <div className="text-center py-10">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow p-6">
        <h1 className="text-3xl font-bold mb-6 text-center">🛠 Manage Community Goals</h1>

        {/* Org selector */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1">Select Organization</label>
          <select
            value={selectedOrg}
            onChange={(e) => setSelectedOrg(e.target.value)}
            className="w-full border rounded-lg p-2"
          >
            <option value="">Select an organization</option>
            {orgs.map((org) => (
              <option key={org.id} value={org.id}>
                {org.name}
              </option>
            ))}
          </select>
        </div>

        {/* Create new goal */}
        <div className="border-t pt-6 mt-6">
          <h2 className="text-xl font-semibold mb-4">➕ Create New Goal</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium mb-1">Quiz</label>
              <select
                value={selectedQuiz || ""}
                onChange={(e) => setSelectedQuiz(Number(e.target.value))}
                className="w-full border rounded-lg p-2"
              >
                <option value="">Select Quiz</option>
                {quizzes.map((quiz) => (
                  <option key={quiz.id} value={quiz.id}>
                    {quiz.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Goal Type</label>
              <select
                value={goalType}
                onChange={(e) =>
                  setGoalType(e.target.value as "score" | "participants")
                }
                className="w-full border rounded-lg p-2"
              >
                <option value="score">Score Goal</option>
                <option value="participants">Participants Goal</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Goal Target</label>
              <input
                type="number"
                value={goalTarget}
                onChange={(e) => setGoalTarget(Number(e.target.value))}
                className="w-full border rounded-lg p-2"
                placeholder="e.g. 1000"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Reward Coins</label>
              <input
                type="number"
                value={rewardCoins}
                onChange={(e) => setRewardCoins(Number(e.target.value))}
                className="w-full border rounded-lg p-2"
                placeholder="e.g. 50"
              />
            </div>
          </div>

          <button
            onClick={handleCreateGoal}
            className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg"
          >
            Create Goal
          </button>
        </div>

        {/* List existing goals */}
        <div className="mt-10">
          <h2 className="text-xl font-semibold mb-4">📋 Existing Goals</h2>

          {goals.length > 0 ? (
            <div className="space-y-4">
              {goals.map((goal) => {
                const progressPercent = Math.min(
                  (goal.current_progress / goal.goal_target) * 100,
                  100
                );

                return (
                  <div
                    key={goal.id}
                    className={`border rounded-lg p-4 ${
                      goal.is_completed ? "bg-green-50 border-green-400" : "bg-white"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold text-lg mb-1">
                          Quiz ID: {goal.quiz_id} ({goal.goal_type})
                        </h3>
                        <p className="text-sm text-gray-600">
                          Target: {goal.goal_target} | Reward: 💰 {goal.reward_coins} coins
                        </p>
                        <p className="text-sm text-gray-600">
                          Progress: {goal.current_progress}/{goal.goal_target} (
                          {progressPercent.toFixed(1)}%)
                        </p>
                      </div>
                      <button
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="text-red-600 hover:text-red-800 text-sm font-medium"
                      >
                        🗑 Delete
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500 text-center">No goals found for this organization.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default CommunityGoalsManager;
